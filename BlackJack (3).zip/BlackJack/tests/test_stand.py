import pytest

from unittest.mock import MagicMock
from game import BlackjackGame

@pytest.fixture
def game():
# Создание экземпляра игры для тестов.
    game = BlackjackGame()
    game.end_game = MagicMock() # Заглушка для метода end_game
    return game

def test_stand_player_bust(game):
# Проверка перебора игрока.
    game.player_hand = ['K', 'Q', '2'] # 10 + 10 + 2 = 22
    game.stand()
    game.end_game.assert_called_with('lose')

def test_stand_dealer_bust(game):
# Проверка перебора дилера.
    game.player_hand = ['7', '9'] # 7 + 9 = 16
    game.dealer_hand = ['K','6', '6'] # 10 + 6 + 6 = 22
    game.stand()
    game.end_game.assert_called_with('win')

def test_stand_player_wins(game):
# Проверка победы игрока.
    game.player_hand = ['9', '9'] # 9 + 9 = 18
    game.dealer_hand = ['7', '8'] # 7 + 8 = 15
    game.stand()
    game.end_game.assert_called_with('win')

def test_stand_dealer_wins(game):
#Проверка победы дилерa.
    game.player_hand = ['6','7'] # 6 + 7 = 13
    game.dealer_hand = ['Q', '8'] # 10 + 8 = 18
    game.stand()
    game.end_game.assert_called_with('lose')

def test_stand_draw(game):
# Проверка ничьей.
    game.player_hand = ['10', '8'] # 10 + 8 = 18
    game.dealer_hand = ['Q&', '8'] # 10 + 8 = 18
    game.stand()
    game.end_game.assert_called_with('draw')