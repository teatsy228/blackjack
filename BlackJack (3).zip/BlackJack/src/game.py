import tkinter as tk
from tkinter import messagebox
import random
import os
from utils import load_users, save_users, load_games_history, save_games_history

class BlackjackGame:
    def __init__(self, root, user):
        self.root = root
        self.root.title("Blackjack")
        self.root.geometry("1024x768")
        self.root.configure(bg="#007f7f")
        self.root.attributes('-fullscreen', True)

        # Данные пользователя
        self.user = user
        self.balance = self.user.get("balance", 1000)
        self.min_bet = 10

        # Игровое состояние
        self.deck = []
        self.player_hand = []
        self.dealer_hand = []
        self.bet = 0

        # Ссылки на изображения карт
        self.card_images = {}

        # Интерфейс
        self.setup_ui()
        self.new_game()

    def setup_ui(self):
        # Метки
        self.player_label = tk.Label(self.root, text="Ваши карты", font=("Arial", 32), bg="#007f7f", fg="white")
        self.player_label.place(x=150, y=20)

        self.dealer_label = tk.Label(self.root, text="Карты Дилера", font=("Arial", 32), bg="#007f7f", fg="white")
        self.dealer_label.place(x=1400, y=20)

        self.balance_label = tk.Label(self.root, text=f"Баланс: {self.balance}$", font=("Arial", 32), bg="#007f7f", fg="white")
        self.balance_label.place(x=20, y=900)

        self.status_label = tk.Label(self.root, text="Ваш ход", font=("Arial", 24), bg="#007f7f", fg="white")
        self.status_label.place(x=20, y=1000)
        
        # Ввод ставки
        self.bet_label = tk.Label(self.root, text="Введите ставку:", font=("Arial", 24), bg="#007f7f", fg="white")
        self.bet_label.place(x=20, y=960)

        self.bet_entry = tk.Entry(self.root, width=15, font=("Arial", 24))
        self.bet_entry.place(x=260, y=960)

        # Кнопки управления
        self.place_bet_button = tk.Button(self.root, text="Сделать ставку", font=("Arial", 12), width=20, command=self.place_bet)
        self.place_bet_button.place(x=600, y=960)

        self.new_game_button = tk.Button(self.root, text="Новая игра", font=("Arial", 12), width=20, command=self.new_game)
        self.new_game_button.place(x=800, y=960)

        self.hit_button = tk.Button(self.root, text="Hit", font=("Arial", 12), width=20, command=self.hit, state=tk.DISABLED)
        self.hit_button.place(x=1000, y=960)

        self.stand_button = tk.Button(self.root, text="Stand", font=("Arial", 12), width=20, command=self.stand, state=tk.DISABLED)
        self.stand_button.place(x=1200, y=960)

        self.exit_button = tk.Button(self.root, text="Выход", font=("Arial", 12), width=20, command=self.root.quit)
        self.exit_button.place(x=1400, y=960)

        # Поля для карт
        self.player_cards_frame = tk.Frame(self.root, bg="#007f7f")
        self.player_cards_frame.place(x=150, y=100)

        self.dealer_cards_frame = tk.Frame(self.root, bg="#007f7f")
        self.dealer_cards_frame.place(x=1400, y=100)

    def new_game(self):
        if self.balance < self.min_bet:
            messagebox.showwarning("Игра окончена", "Недостаточно средств для продолжения игры!")
            return

        self.deck = self.create_deck()
        random.shuffle(self.deck)

        self.player_hand = []
        self.dealer_hand = []
        self.bet = 0

        self.update_user_balance()
        self.status_label.config(text="Ваш ход")
        self.clear_cards()

        self.hit_button.config(state=tk.DISABLED)
        self.stand_button.config(state=tk.DISABLED)
        self.bet_entry.config(state=tk.NORMAL)
        self.place_bet_button.config(state=tk.NORMAL)

    def create_deck(self):
        return [(rank, suit) for suit in ['Clubs', 'Diamonds', 'Hearts', 'Spades'] 
                for rank in ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace']]

    def place_bet(self):
        try:
            self.bet = int(self.bet_entry.get())
            if self.bet < self.min_bet:
                messagebox.showwarning("Ошибка", f"Минимальная ставка: {self.min_bet}$")
                return
            if self.bet > self.balance:
                messagebox.showwarning("Ошибка", "Недостаточно средств для ставки!")
                return

            self.start_game()
        except ValueError:
            messagebox.showwarning("Ошибка", "Введите корректную ставку!")

    def start_game(self):
        self.bet_entry.config(state=tk.DISABLED)
        self.place_bet_button.config(state=tk.DISABLED)

        self.player_hand = [self.deck.pop(), self.deck.pop()]
        self.dealer_hand = [self.deck.pop(), self.deck.pop()]

        self.update_display()
        self.hit_button.config(state=tk.NORMAL)
        self.stand_button.config(state=tk.NORMAL)
    
    def load_hidden_card_image(self):
        # """Загрузить изображение скрытой карты (cardshirt.png)."""
            cardshirt_path = os.path.join("src","assets", "cardshirt.png")
            if os.path.exists(cardshirt_path):
                if "cardshirt" not in self.card_images:
                    self.card_images["cardshirt"] = tk.PhotoImage(file=cardshirt_path)
                return self.card_images["cardshirt"]
            return None
        

    def load_card_image(self, card):
        rank, suit = card
        card_name = f"{rank.lower()}of{suit.lower()}.png"
        card_path = os.path.join("src","assets", card_name)
        if os.path.exists(card_path):
            if card_name not in self.card_images:
                self.card_images[card_name] = tk.PhotoImage(file=card_path)
            return self.card_images[card_name]
        return None

    def update_display(self):
        # Очистить старые карты
        self.clear_cards()

        # Отобразить карты игрока
        for card in self.player_hand:
            image = self.load_card_image(card)
            if image:
                label = tk.Label(self.player_cards_frame, image=image, bg="#007f7f")
                label.image = image  # Сохранить ссылку, чтобы изображение не исчезло
                label.pack(side=tk.LEFT)

        # Отобразить карты дилера
        for i, card in enumerate(self.dealer_hand):
            if i == 0:  # Первая карта (скрытая)
                hidden_image = self.load_hidden_card_image()
                if hidden_image:
                    label = tk.Label(self.dealer_cards_frame, image=hidden_image, bg="#007f7f")
                    label.image = hidden_image
                    label.pack(side=tk.LEFT)
            else:
                image = self.load_card_image(card)
                if image:
                    label = tk.Label(self.dealer_cards_frame, image=image, bg="#007f7f")
                    label.image = image
                    label.pack(side=tk.LEFT)


    def clear_cards(self):
        for widget in self.player_cards_frame.winfo_children():
            widget.destroy()
        for widget in self.dealer_cards_frame.winfo_children():
            widget.destroy()

    def hit(self):
        self.player_hand.append(self.deck.pop())
        if self.hand_value(self.player_hand) > 21:
            self.end_game("lose")
        else:
            self.update_display()

    def stand(self):
        while self.hand_value(self.dealer_hand) < 17:
            self.dealer_hand.append(self.deck.pop())

        player_score = self.hand_value(self.player_hand)
        dealer_score = self.hand_value(self.dealer_hand)

        self.player_score = player_score
        self.dealer_score = dealer_score

        if dealer_score > 21 or player_score > dealer_score:
            self.end_game("win")
        elif player_score < dealer_score:
            self.end_game("lose")
        else:
            self.end_game("draw")

    def hand_value(self, hand):
        value = sum(self.card_value(card) for card in hand)
        aces = sum(1 for card in hand if card[0] == 'Ace')
        while value > 21 and aces:
            value -= 10
            aces -= 1
        return value
    
    def card_value(self, card):
        rank = card[0]
        if rank in ['Jack', 'Queen', 'King']:
            return 10
        elif rank == 'Ace':
            return 11
        return int(rank)

    def end_game(self, result):
        if result == "win":
            self.balance += self.bet
            messagebox.showinfo("Результат", "Вы выиграли!")
        elif result == "lose":
            self.balance -= self.bet
            messagebox.showinfo("Результат", "Вы проиграли!")
        else:
            messagebox.showinfo("Результат", "Ничья!")

        
        # Добавляем запись в историю
        history = load_games_history()
        history.append({
            "name": self.user['name'],  # Имя текущего игрока
            "result": result,           # Результат игры
            "bet": self.bet             # Размер ставки
        })
        save_games_history(history)  # Сохраняем историю

        self.update_user_balance()
        self.new_game()

    def update_user_balance(self):
        users = load_users()  # Загружаем всех пользователей
        for u in users:
            if u['id'] == self.user['id']:
                u['balance'] = self.balance  # Обновляем баланс текущего пользователя
                break
        save_users(users)  # Сохраняем обновленные данные
        self.balance_label.config(text=f"Баланс: ${self.balance}")

def run_blackjack_game(selected_user):
    root = tk.Tk()
    game = BlackjackGame(root, selected_user)
    root.mainloop()
