import tkinter as tk
from tkinter import messagebox
from game import run_blackjack_game
from utils import load_users, save_users, load_games_history, save_games_history#, get_exchange_rates

class MenuWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("Управление пользователями")
        self.root.geometry("500x400")
        self.root.attributes('-fullscreen', True)
        self.root.configure(bg="#0a5c5c")

        self.create_widgets()
        self.update_listbox()
        self.update_games_listbox()
        # self.update_currency_listbox()

    def create_widgets(self):
        tk.Label(self.root, font=('Arial', 32), background="#0a5c5c", text="BlackJack").pack()
        tk.Label(self.root, font=('Arial', 16), background="#0a5c5c", text="Регистрация").pack()

        tk.Label(self.root, font=('Arial', 16), background="#0a5c5c", text="Имя пользователя:").pack()
        self.name_entry = tk.Entry(self.root)
        self.name_entry.pack()

        tk.Label(self.root, font=('Arial', 16), background="#0a5c5c", text="Пароль:").pack()
        self.password_entry = tk.Entry(self.root, show="*")
        self.password_entry.pack()

        tk.Button(self.root, text="Добавить пользователя", background="#008080", command=self.add_user).pack()

        self.listbox = tk.Listbox(self.root)
        self.listbox.pack(pady=10)

        tk.Button(self.root, background="#008080", font=('Arial', 32), text="Запустить Blackjack", command=self.start_blackjack).place(x=760, y=700)

        tk.Label(self.root, font=('Arial', 16), background="#0a5c5c", text="История игр:").place(x=10, y=250)
        self.listbox_games = tk.Listbox(self.root, height=35, width=50)
        self.listbox_games.place(x=15, y=280)

        tk.Button(self.root, background="#008080", text="Выход", font=("Arial", 12), width=20, command=self.root.quit).place(x=870, y=900)

        # tk.Label(self.root, font=('Arial', 16), background="#0a5c5c", text="Курсы валют относительно USD:").place(x=1570, y=750)
        # self.currency_listbox = tk.Listbox(self.root, height=15, width=50)
        # self.currency_listbox.place(x=1600, y=780)

    def update_listbox(self):
        self.listbox.delete(0, tk.END)
        users = load_users()
        for user in users:
            self.listbox.insert(tk.END, f"ID: {user['id']}, Имя: {user['name']}")

    def update_games_listbox(self):
        self.listbox_games.delete(0, tk.END)
        history = load_games_history()
        for entry in history:
            self.listbox_games.insert(tk.END, f"Игрок: {entry['name']}, Результат: {entry['result']}, Ставка: ${entry['bet']}")

    # def update_currency_listbox(self):
    #     rates = get_exchange_rates()
    #     if rates:
    #         self.currency_listbox.delete(0, tk.END)
    #         for currency, rate in rates.items():
    #             self.currency_listbox.insert(tk.END, f"{currency}: {rate:.2f}")

    def add_user(self):
        name = self.name_entry.get()
        password = self.password_entry.get()
        if name and password:
            users = load_users()
            user_id = len(users) + 1
            users.append({"id": user_id, "name": name, "password": password, "balance": 1000})
            save_users(users)
            self.update_listbox()
            self.name_entry.delete(0, tk.END)
            self.password_entry.delete(0, tk.END)
        else:
            messagebox.showerror("Ошибка", "Заполните все поля.")

    def start_blackjack(self):
        selected = self.listbox.curselection()
        if not selected:
            messagebox.showerror("Ошибка", "Выберите пользователя для запуска игры.")
            return
        user_index = selected[0]
        users = load_users()
        selected_user = users[user_index]
        password = self.password_entry.get()
        if password != selected_user['password']:
            messagebox.showerror("Ошибка", "Неверный пароль.")
            return
        self.root.destroy()
        run_blackjack_game(selected_user)
