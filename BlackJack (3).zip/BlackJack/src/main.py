import tkinter as tk
from menu import MenuWindow

if __name__ == "__main__":
    root = tk.Tk()
    app = MenuWindow(root)
    root.mainloop()
