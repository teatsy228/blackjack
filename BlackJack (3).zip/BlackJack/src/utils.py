import json
import os
import requests
from tkinter import messagebox

USERS_FILE = "users.json"
GAMES_HISTORY_FILE = "games_history.json"

if not os.path.exists(USERS_FILE):
    with open(USERS_FILE, "w") as f:
        json.dump([], f)

if not os.path.exists(GAMES_HISTORY_FILE):
    with open(GAMES_HISTORY_FILE, "w") as f:
        json.dump([], f)

def load_users():
    with open(USERS_FILE, "r") as f:
        return json.load(f)

def save_users(users):
    with open(USERS_FILE, "w") as f:
        json.dump(users, f, indent=4)

def load_games_history():
    with open(GAMES_HISTORY_FILE, "r") as f:
        return json.load(f)

def save_games_history(history):
    with open(GAMES_HISTORY_FILE, "w") as f:
        json.dump(history, f, indent=4)

# def get_exchange_rates():
#     api_key = "cur_live_4vVXwPZTEnuw0LnxhGK8msDMq312fWSHPsVmeU8Y"
#     url = f"https://api.currencyapi.com/v3/latest?apikey={api_key}&base_currency=USD"
#     response = requests.get(url)
#     if response.status_code == 200:
#         data = response.json()
#         if 'data' in data:
#             return {currency: details['value'] for currency, details in data['data'].items()}
#         else:
#             messagebox.showerror("Ошибка", "Ошибка при получении данных с CurrencyAPI.")
#             return None
#     else:
#         messagebox.showerror("Ошибка", "Не удалось подключиться к CurrencyAPI.")
#         return None
